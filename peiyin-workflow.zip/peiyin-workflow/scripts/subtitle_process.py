#!/usr/bin/env python3
"""
字幕处理 - 严格按断句规则执行
a. 的禁止行尾   b. 原文标点优先   c. 动词后断
d. 主干不拆     e. 修饰不拆       f. 去引号保内容
g. 列表项独立   h. 连词放行首     i. 序号独立
"""
import re, os, sys, jieba

SRC_DIR = '.'  # 无参数时使用当前目录
OUT_DIR = '/Users/caowei/Documents/codebuddy_work/配音/output'
MAX_LEN = 14
TARGET = 12

CONJUNCTIONS = {'但', '而', '却', '则', '也', '就', '才', '都', '还', '又', '再', '更'}
ORDINALS = {'第一', '第二', '第三', '第四', '第五', '第六', '1', '2', '3', '一', '二', '三'}
LIST_SEPS = {'比如', '例如', '像', '包括', '以及'}
QUOTE_MAP = str.maketrans('', '', '\u201c\u201d\u2018\u2019""''「」『』【】《》')


def score_break(prev_word, next_word):
    score = 0
    prev = prev_word[-1] if prev_word else ''
    if prev == '的':
        return -100
    if next_word in CONJUNCTIONS or (next_word and next_word[0] in CONJUNCTIONS and len(next_word) == 1):
        score += 8
    if prev_word and len(prev_word) >= 1 and prev_word[-1] in '了着过呢吧啊呀嘛':
        score += 6
    if next_word in ORDINALS:
        score += 7
    if next_word in LIST_SEPS:
        score += 4
    if len(next_word) == 1 and next_word in '在把被让给对从向跟和与为由':
        score += 3
    return score


def split_smart(text):
    words = list(jieba.cut(text))
    wp = []
    pos = 0
    for w in words:
        wp.append((pos, pos + len(w), w))
        pos += len(w)

    result = []
    start = 0
    while start < len(text):
        rem = len(text) - start
        if rem <= MAX_LEN:
            result.append(text[start:])
            break

        best_pos = start + min(TARGET, rem)
        best_score = -999

        for end, _, w in wp:
            if end <= start + 3:
                continue
            if end > start + MAX_LEN:
                break
            if text[end - 1] == '的':
                continue

            next_w = ''
            for s2, e2, w2 in wp:
                if s2 == end:
                    next_w = w2
                    break

            rule_score = score_break(w, next_w)
            if rule_score < 0:
                continue

            offset = end - start
            len_score = -abs(offset - TARGET) * 0.3
            total = rule_score * 2 + len_score + offset * 0.1
            if total > best_score:
                best_score = total
                best_pos = end

        if best_pos > start and best_pos < len(text) and text[best_pos - 1] == '的':
            if best_pos + 1 <= start + MAX_LEN:
                best_pos += 1
            elif best_pos - 2 >= start + 3:
                best_pos -= 1

        result.append(text[start:best_pos])
        start = best_pos

    return result


def clean_text(sent):
    sent = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', sent)
    clean = re.sub(r'[，、；：,;:\.\?\!！？\s]+', '', sent)
    clean = clean.translate(QUOTE_MAP)
    clean = re.sub(r'\s+', '', clean)
    return clean


def process_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()

    text = re.sub(r'\*\*[^*]+\*\*', '', text)
    raw_segments = re.split(r'([，、；：。！？\n]+)', text)

    sentences = []
    for seg in raw_segments:
        seg = seg.strip()
        if not seg or re.match(r'^[，、；：。！？\s]+$', seg):
            continue
        sentences.append(seg)

    lines = []
    for sent in sentences:
        sent = sent.strip()
        if not sent:
            continue
        clean = clean_text(sent)
        if not clean:
            continue
        sub = split_smart(clean)
        lines.extend(sub)

    i = 0
    while i < len(lines) - 1:
        if lines[i] and lines[i][-1] == '的' and len(lines[i+1]) + 1 <= MAX_LEN:
            lines[i] = lines[i][:-1]
            lines[i+1] = '的' + lines[i+1]
            if not lines[i]:
                lines.pop(i)
                continue
        i += 1

    out_name = os.path.splitext(os.path.basename(filepath))[0] + '_字幕处理.md'
    out_path = os.path.join(OUT_DIR, out_name)
    content = [l for l in lines if l.strip()]

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(content) + '\n')

    over14 = [l for l in content if len(l) > MAX_LEN]
    over12 = [l for l in content if len(l) > TARGET]
    de_end = [l for l in content if l and l[-1] == '的']
    print(f"✅ {out_name}")
    print(f"   行: {len(content)} | >12: {len(over12)} | >14: {len(over14)} | 的尾: {len(de_end)}")


# 命令行参数解析
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('path', nargs='?', help='文件路径或目录路径')
parser.add_argument('--file', help='处理单个文件')
args = parser.parse_args()

if args.file:
    # 单文件模式
    process_file(args.file)
elif args.path:
    p = args.path
    if os.path.isfile(p) and p.endswith('.md'):
        process_file(p)
    elif os.path.isdir(p):
        for fname in sorted(os.listdir(p)):
            if fname.endswith('.md') and not fname.startswith('.'):
                process_file(os.path.join(p, fname))
else:
    for fname in sorted(os.listdir(SRC_DIR)):
        if fname.endswith('.md') and not fname.startswith('.'):
            process_file(os.path.join(SRC_DIR, fname))

print("\n完成！")
